package tech.kbt.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import tech.kbt.entity.Student;



public interface StudentRepository extends JpaRepository<Student, Long>{

}
